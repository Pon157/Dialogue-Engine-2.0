from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    DATABASE_URL: str
    MASTER_BOT_TOKEN: str
    BOT_POLL_INTERVAL: int = 5


settings = Settings()
